Exercise 2.1 and 2.2 were not understandable. the lecture did not provide enough information so that it was clear what the assignment was.

In the model created with Xtext, I was not able to get correct references to the Wizard neither the Pages.
I probably should have implemented an attribute "ID" for the classes "Wizard" and "Page".
Since we were not told to do so on the exercise sheet, I did not implement it.
For the model created with the tree-like editor it was no problem to reference the objects.
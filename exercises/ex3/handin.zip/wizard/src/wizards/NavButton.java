/**
 */
package wizards;

import org.eclipse.emf.ecore.EOperation;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Nav Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wizards.WizardsPackage#getNavButton()
 * @model
 * @generated
 */
public interface NavButton extends Button {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	EOperation navigate();

} // NavButton

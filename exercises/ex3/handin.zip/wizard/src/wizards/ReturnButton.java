/**
 */
package wizards;

import org.eclipse.emf.ecore.EOperation;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Return Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wizards.WizardsPackage#getReturnButton()
 * @model
 * @generated
 */
public interface ReturnButton extends Button {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	EOperation return_();

} // ReturnButton

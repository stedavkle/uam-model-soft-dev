/**
 */
package wizards;

import org.eclipse.emf.ecore.EOperation;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Close Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wizards.WizardsPackage#getCloseButton()
 * @model
 * @generated
 */
public interface CloseButton extends Button {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	EOperation close();

} // CloseButton

package main;

import wizard.Wizard;

public class Main {
	public static void main(String[] args) {
		Wizard wizard = new Wizard();
		wizard.showWizard();
	}
}
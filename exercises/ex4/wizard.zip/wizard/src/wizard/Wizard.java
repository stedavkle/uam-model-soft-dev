package wizard;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;

import javax.swing.*;
import listeners.*;

public class Wizard extends JFrame {
	final static String PAGE_1 = "Page 1";
	final static String PAGE_2 = "Page 2";
	final static String PAGE_3 = "Page 3";

	public Wizard () {
		super ("My wizard");
		
		JPanel wizard, page, fields, buttons;
		JButton button;
		JLabel  label;
		JTextField text;
		JCheckBox check;
		
		// panel containing all pages
		wizard = new JPanel(new CardLayout());
		
		// 1st page of wizard
		
		// - fields
		fields  = new JPanel(new GridLayout(0, 2));
		label   = new JLabel("Name");
		text    = new JTextField(10);
		fields.add(label);
		fields.add(text);
		// - buttons
		buttons = new JPanel();		
		button  = new JButton("Next");
		button.addActionListener(new ChangePageListener(wizard, PAGE_2));
		buttons.add(button);
		button  = new JButton("Cancel");
		button.addActionListener(new CloseWizardListener(this));
		buttons.add(button);
		// - adding page to wizard
		page    = new JPanel(new BorderLayout());
		page.add(fields,  BorderLayout.CENTER);
		page.add(buttons, BorderLayout.SOUTH);
		wizard.add(page, PAGE_1);
		
		// 2nd page of wizard
		
		// - fields
		fields  = new JPanel(new GridLayout(0, 2));
		label   = new JLabel("create src folder");
		check   = new JCheckBox();
		check.setSelected(true); // to select the checkbox
		fields.add(label);
		fields.add(check);
		// - buttons
		buttons = new JPanel();		
		button  = new JButton("Finish");
		button.addActionListener(new CloseWizardListener(this));
		buttons.add(button);
		// - adding page to wizard
		page    = new JPanel(new BorderLayout());
		page.add(fields,   BorderLayout.CENTER);
		page.add(buttons, BorderLayout.SOUTH);
		wizard.add(page, PAGE_2);
		
		// add panel to window
		getContentPane().add(wizard);
	}
	
	/**
	 * show wizard
	 */
	public void showWizard() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setVisible(true);
	}
}